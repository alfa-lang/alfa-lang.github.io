import dataclasses
import typing
import alfa.rt.AlfaServiceFactory
from alfa.rt.AlfaBuiltinFunctions import AlfaBuiltinFunctions


from alfa.rt.RuntimeContext import RuntimeContext

class BuilderConfig:
    # """Type holding runtime configuration and pluggable behaviour required"""
    def __init__(self,
                 runtime_context = RuntimeContext(),
                 should_validate_onbuild = True,
                 meta_field_prefix = "$",
                 is_skip_unknown_fields = False,
                 should_clone_collections_on_build = False,
                 assert_mandatory_fields_set = True,
                 service_factories = { } ):
        self.runtime_context = runtime_context
        self.should_validate_onbuild  = should_validate_onbuild
        self.meta_field_prefix  = meta_field_prefix
        self.is_skip_unknown_fields  = is_skip_unknown_fields
        self.should_clone_collections_on_build  = should_clone_collections_on_build
        self.assert_mandatory_fields_set  = assert_mandatory_fields_set
        self.service_factories = service_factories
        pass

    # def should_validate_onbuild(self):
    #     return self._should_validate_onbuild
    #
    # def assert_mandatory_fields_set(self):
    #     return self._assert_mandatory_fields_set
    #
    # def should_clone_collections_on_build(self):
    #     return self._should_clone_collections_on_build

    def get_service_factory( self, factory_type : type ):
        return self.service_factories[ str(type(factory_type)) ]

    def add_service_factory(self, factory_type : type, factory_implementation : alfa.rt.AlfaServiceFactory.AlfaServiceFactory ):
        self.service_factories[str(type(factory_type))] = factory_implementation

    # def is_skip_unknown_fields(self):
    #     return self._is_skip_unknown_fields
    #
    # def get_meta_field_prefix(self):
    #     return self._meta_field_prefix


    def builtins(self) -> AlfaBuiltinFunctions :
        return self.runtime_context.builtins