import abc


class AlfaObject(abc.ABC):
    """Base class implemented by all Alfa Python objects corresponding to user-defined-types in Alfa."""
    pass
