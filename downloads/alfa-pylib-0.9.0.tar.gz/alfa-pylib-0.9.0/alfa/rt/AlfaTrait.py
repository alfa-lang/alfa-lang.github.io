from alfa.rt.AlfaObject import AlfaObject


class AlfaTrait(AlfaObject):
    """Base class implemented by all Alfa Python objects corresponding to traits in Alfa."""
    pass
