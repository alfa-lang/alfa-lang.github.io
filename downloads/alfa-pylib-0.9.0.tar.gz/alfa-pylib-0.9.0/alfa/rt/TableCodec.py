import alfa.rt
import datetime
import decimal
import uuid
import base64
import typing

import isodate

import alfa.rt.model.UdtMetaType as UdtMetaType
from alfa.rt.Validator import Validator
from alfa.rt.ClassLoader import ClassLoader
from alfa.rt.Stack import Stack

from alfa.rt.model.UdtMetaType import UdtMetaType
from alfa.rt.model.ScalarType import ScalarType

from alfa.rt.AlfaObject import AlfaObject
from alfa.rt.BuilderConfig import BuilderConfig
from alfa.rt.JsonCodec import JsonCodec

from alfa.rt.AlfaRandomizer import AlfaRandomizer

class Row:
    def __init__(self, r = None):
        if r is None:
            self.cols = {}
        else:
            self.cols = r.cols.copy()

    def _set_value(self, cname, value):
        if cname in self.cols and self.cols[cname] != value:
            raise Exception("Col:" + cname + " old:"+ str(self.cols[cname]) + " new:" + str(value))
        else:
            self.cols[cname] = value

    def __str__(self):
        return self._stringify(len(self.cols))

    def get_value(self,col_name):
        if col_name in self.cols:
            return self.cols[col_name]
        else:
            return None

    def _stringify(self, colnames):
        s = "|"
        for cn in colnames:
            if cn in self.cols:
                s += Table._fmt_col(str(self.cols[cn]).ljust(20)) + "|"
            else:
                s += Table._fmt_col("").ljust(20) + "|"

        s += "\n"
        return s


class Table:
    def __init__(self, desc):
        self._desc = desc
        self._current_row = -1
        self.columns = {}  # Name to type/class
        self.rows = []

    def _insert_row(self):
        self.rows.append(Row())
        self._current_row += 1

    def _update(self, coltype, colname, val):
        row = self.rows[self._current_row]
        row._set_value(colname, val)

        if colname in self.columns:
            old_dt = self.columns[colname]

            if old_dt != coltype:
                raise Exception("For column " + colname + " old type " + old_dt + " different to " + coltype)
        else:
            self.columns[colname] = coltype

    def _clone_and_advance_row(self,pre_vector_expansion_row):
        if self._current_row == -1:
            raise Exception()
        newRow = Row(pre_vector_expansion_row)
        self.rows.append(newRow)
        self._current_row += 1

    def _get__current_row_object_copy(self):
        r = self.rows[self._current_row]
        return Row(r)

    def __str__(self):
        s = "|"
        uline = "|"
        for c in self.columns:
            c = Table._fmt_col(c)
            s += c.ljust(20) + "|"
            uline += "=" * 20 + "|"

        s += "\n"
        s += uline + "\n"
        for r in self.rows:
            s += r._stringify(self.columns)

        return s

    @staticmethod
    def _fmt_col(_s):

        s = str(_s)
        if len(s) > 20:
            s = "..." + s[len(s)-20+3:]
        return s

class CurrentObjectInfo:
    def __init__(self):
        self.requires_dimension_col = False

    def set_pre_vector_visit_row(self, r: Row):
        if self.has_pre_vector_visit_row():
            raise Exception("Pre vector visit row already set")
        self.pre_vector_expansion_row = r

    def has_pre_vector_visit_row(self):
        return hasattr(self, "pre_vector_expansion_row")


class TableCodec:
    def __init__(self, alfa_object):
        self.alfa_object = alfa_object
        self.table = Table( alfa_object._alfa_descriptor() )
        self.curr_field_stack = Stack()
        self.vector_info = Stack()
        self.nested_vector_level = 0

    def to_table(self) -> Table:
        self.table._insert_row()
        self._consume_obj(self.alfa_object)
        return self.table

    @staticmethod
    def get_csv_contents(path):
        if path.startswith("http"):
            import requests
            download = requests.get(path)
            return download.content.decode('utf-8-sig')
        else:
            f = open(path, mode='r', encoding='utf-8-sig')
            lines = f.read()
            f.close()
            return lines

    @staticmethod
    def csv_to_objects(type_name : str, contents : str, delimeter = ",", skip_unknown_cols = False, skip_error_rows = False, builder_config : BuilderConfig = BuilderConfig() ) -> typing.Sequence[AlfaObject]:

        import csv

        objects = []

        reader = csv.reader(contents.splitlines(), delimiter= delimeter)

        line_count = 0
        for row in reader:
            line_count += 1

            if line_count == 1:
                header = row

                clazz = ClassLoader.load(type_name)
                model = clazz._alfa_descriptor()

                for field in header:
                    field = field.strip()
                    ftype = model.field_alfa_type(field)

                    if ftype == None:
                        err = "unknown column/field '" + field + "' used in CSV data"
                        if skip_unknown_cols:
                            print("Ignoring " + err)
                        else:
                            raise Exception(err)

            else:
                if len(header) != len(row):
                    err = "header and row size mismatch " + str(len(header)) + " and " + str(len(row)) + " for row " + str(line_count)
                    if skip_error_rows:
                        print("Ignoring " + err)
                    else:
                        raise Exception(err)

                obj = TableCodec.__read_csv_object(line_count, type_name, model, header, row, skip_error_rows, builder_config)
                if obj != None:
                    objects.append( obj )

        return objects

    @staticmethod
    def  __read_csv_object(line_count, type_name, model, header, row, skip_error_rows, builder_config )  -> alfa.rt.AlfaObject.AlfaObject:

        fmap = {}
        fmap[ builder_config.meta_field_prefix + "type"] = type_name

        for field, value in zip(header, row):
            ftype = model.field_alfa_type(field)

            if ftype == None:
                pass
            else:
                fmap[field] = value

        try:
            alfaObj = JsonCodec._from_dict(None, fmap, builder_config)
            return alfaObj
        except Exception as ex:
            err = "error while reading line " + str(line_count) + ". " + str(ex)
            if skip_error_rows:
                print("Ignoring " + err)
                return None
            else:
                raise Exception(err)

    def _col_order(self,desc):
        non_vecs = []
        vecs = []

        for fld in desc.all_fields().values():
            t_str = str(fld.type)
            if t_str.startswith("typing.Set[") or t_str.startswith("typing.Sequence[") or t_str.startswith("typing.Mapping["):
                vecs.append(fld)
            else:
                non_vecs.append(fld)

        return (non_vecs, vecs)


    def _current_field_name(self):
        if self.curr_field_stack.is_empty():
            return ""
        else:
            return self.curr_field_stack.peek()

    def _get_attrval(self, alfatype, param, else_val = None):
        if hasattr(alfatype, param):
            v = getattr(alfatype, param)
            if v is None:
                return else_val
            else:
                return v

        else:
            return else_val

    def _consume_obj(self, obj):
        co = CurrentObjectInfo()
        self.vector_info.push(co)

        desc = obj._alfa_descriptor()
        t = desc.alfa_type()

        if t == UdtMetaType.unionType:
            self.table._update(ScalarType.stringType, self._gen_col_name() + "__Case", obj.case_name())

        if t == UdtMetaType.enumType:
            self.table._update(ScalarType.stringType, self._gen_col_name(), str(obj.name))

        if t == UdtMetaType.traitType:
            self.table._update(ScalarType.stringType, self._gen_col_name() + "__Type", desc.name())

        self.___consume_obj(obj)

        self.vector_info.pop()

    def ___consume_obj(self, obj):
        desc = obj._alfa_descriptor()
        t = desc.alfa_type()

        if t == UdtMetaType.unionType:
            cn = obj.case_name()
        else:
            if t == UdtMetaType.entityType:
                k = obj.key()
                if k is not None:
                    self._consume_obj(k)

            non_vecs, vecs = self._col_order(desc)
            ordered_cols = non_vecs + vecs

            if len(vecs) > 1:
                self.vector_info.peek().requires_dimension_col = True

            for fld in ordered_cols:
                # Key is handled above
                if fld.name == '__key__':
                    continue

                v = getattr(obj, fld.name)
                field_alfa_type = desc.field_alfa_type(fld.name)

                self._pre_consume_field(fld.name, fld.type)

                self._consume_val(field_alfa_type, fld.type, v)

                self._post_consume_field(fld.name, fld.type)
        pass

    def _gen_col_name(self):
        return self.curr_field_stack.delimited_str("_")

    def _consume_val(self, alfatype, pytype, val):

        cn = self._gen_col_name()
        t_str = str(pytype)
        valtype = type(val)

        if pytype == int or pytype == str or pytype == float or pytype == bool or pytype == datetime.date \
                or pytype == datetime.datetime or pytype == isodate.Duration or pytype == datetime.timedelta \
                or pytype == datetime.time or pytype == uuid.UUID or pytype == bytes or ClassLoader.is_uri_class(pytype) \
                or pytype == decimal.Decimal or ClassLoader.is_alfa_nativetype(pytype):
            self.table._update(pytype, cn, val)

        elif Validator._is_optional(pytype):
            self.table._update(pytype, cn + "_IsSet", val is not None)
            if val is not None:
                argt = pytype.__args__
                dt = self._get_attrval(alfatype, "ComponentType")
                self._consume_val(dt, argt[0], val)

        elif t_str.startswith("alfa.rt.Try.Try["):
            args = pytype.__args__
            dic = {}

            if val.is_Result():
                dt = self._get_attrval(alfatype, "ResultType") # But try<T> has no meta of type, this will be None?
                self._consume_val( dt, args[0], val.Result)
            else:
                dt = self._get_attrval(alfatype, "FailureType")
                self._consume_val(dt, alfa.rt.TryFailure.TryFailure, val.Failure)

        elif t_str.startswith("alfa.rt.Either.Either["):
            args = pytype.__args__
            dic = {}
            if val.is_Left():
                dt = self._get_attrval(alfatype, "LeftType")
                self._consume_val(dt, args[0], val.Left)
            else:
                dt = self._get_attrval(alfatype, "RightType")
                self._consume_val(dt, args[1], val.Right)

        elif t_str.startswith("alfa.rt.Compressed.Compressed["):
            b64_str = base64.b64encode(val.encoded).decode('ascii')
            self.table._update(str, cn, b64_str)

        elif t_str.startswith("alfa.rt.Encrypted.Encrypted["):
            b64_str = base64.b64encode(val.encoded).decode('ascii')
            self.table._update(str, cn, b64_str)

        elif t_str.startswith("typing.Mapping[") and valtype == dict:
            args = pytype.__args__
            self.nested_vector_level += 1

            sz = len(val)
            co = self._pre_vector_process_init(sz, None)
            row = RowCounter(0)

            for k in val:
                v = val[k]

                self._vector_pre_iterate_init(co, None, row)

                kt = self._get_attrval(alfatype, "KeyType")
                vt = self._get_attrval(alfatype, "ValueType")

                kn = self._get_attrval(alfatype, "KeyName", "Key")
                vn = self._get_attrval(alfatype, "ValueName", "Value")

                kName = kn + self._nested_level()
                self._pre_consume_field(kName, args[0])
                self.vector_info.push(CurrentObjectInfo())
                self._consume_val(kt, args[0], k)
                self.vector_info.pop()
                self._post_consume_field(kName, args[0])

                vName = vn + self._nested_level()
                self._pre_consume_field(vName, args[1])
                self.vector_info.push(CurrentObjectInfo())
                self._consume_val(vt, args[1], v)
                self.vector_info.pop()
                self._post_consume_field(vName, args[1])

            self.nested_vector_level += -1

        elif t_str.startswith("typing.Sequence[") and valtype == list:
            args = pytype.__args__

            self.nested_vector_level += 1

            sz = len(val)
            co = self._pre_vector_process_init(sz, None)
            row = RowCounter(0)

            for _i in range(len(val)):
                self._vector_pre_iterate_init(co, None, row)

                i = sz - _i
                self.table._update(int, "__" + self._gen_col_name() + "__Id" + self._nested_level(), i )

                e = val[i-1]

                at = self._get_attrval(alfatype, "ComponentType")

                self.vector_info.push(CurrentObjectInfo())
                self._consume_val(at, args[0], e)
                self.vector_info.pop()

            self.nested_vector_level += -1


        elif t_str.startswith("typing.Union[") and val is None:
            return None

        elif t_str.startswith("typing.Set[") and (valtype == set or valtype == frozenset):
            args = pytype.__args__

            self.nested_vector_level += 1

            sz = len(val)
            co = self._pre_vector_process_init(sz, None)
            row = RowCounter(0)

            for _i, e in zip(range(len(val)), val):
                self._vector_pre_iterate_init(co, None, row)

                i = sz - _i
                self.table._update(int, "__" + self._gen_col_name() + "__Id" + self._nested_level(), i)

                self.vector_info.push(CurrentObjectInfo())

                at = self._get_attrval(alfatype, "ComponentType")

                self._consume_val(at, args[0], e)
                self.vector_info.pop()

            self.nested_vector_level += -1

        elif ClassLoader.is_alfa_udt_class(pytype):
            self._consume_obj(val)

        else:
            raise Exception("Type not handled:" + str(pytype) + " field:" + self._gen_col_name() + ". Value: " + str(val))


    def _nested_level(self):
        if self.nested_vector_level == 1:
            return ""
        else:
            return "_L" + str( self.nested_vector_level - 1 )


    def _pre_vector_process_init(self, dataSize, sizeMin):
        co = self.vector_info.peek()

        # If another vector was written, start this on a new row, otherwise same row is fine
        if co.has_pre_vector_visit_row():
            self.table._clone_and_advance_row(co.pre_vector_expansion_row)

        # Save the row shape before we started looping for this vector. If another
        # vector is visited, it too will used the same non-vector col values
        if not co.has_pre_vector_visit_row():
            co.set_pre_vector_visit_row( self.table._get__current_row_object_copy() )

        if co.requires_dimension_col:
            self.table._update(str, "__Dimension", self._current_field_name())

        sizePresent = sizeMin is not None
        emptyReqd = not sizePresent or ( sizePresent and sizeMin == 0 )

        if emptyReqd and dataSize == 0:
            self.table._update(bool, "__" + self._gen_col_name() + "_IsEmpty" + self._nested_level(), True )

        return co

    def _vector_pre_iterate_init(self, co, sizeMin, row):
        if row.get_and_increment() > 0:
            self.table._clone_and_advance_row(co.pre_vector_expansion_row)

        emptyReqd = sizeMin is None or ( sizeMin is not None and sizeMin == 0 )

        if emptyReqd:
            self.table._update(bool, "__" + self._gen_col_name() + "_IsEmpty" + self._nested_level(), False )

        if co.requires_dimension_col:
            self.table._update(str, "__Dimension" + self._nested_level(), self._current_field_name())

    def _pre_consume_field(self, name, type):
        self.curr_field_stack.push(name)

    def _post_consume_field(self, name, type):
        self.curr_field_stack.pop()

class RowCounter:
    def __init__(self, v):
        self.count = v

    def get_and_increment(self):
        v = self.count
        self.count += 1
        return v


# def test(type):
#     r = AlfaRandomizer([])
#     o = r.random(type)
#     f = TableCodec(o)
#     t = f.to_table()
#     print(t)
#
# test("Demo.Player")

# contents =  "PlayerName,Position,Ranking\n"
# contents += "Joe,Midfield,3\n"
# contents += "Bob,Midfield,17\n"
#
# objs = TableCodec.csv_to_objects("Demo.Player", contents, skip_unknown_cols = True, skip_error_rows = True, builder_config = BuilderConfig( should_validate_onbuild = False) )
#
# print(objs)