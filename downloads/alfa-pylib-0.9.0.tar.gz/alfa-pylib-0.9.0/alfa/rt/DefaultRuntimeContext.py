
import alfa.rt

class DefaultRuntimeContext(alfa.rt.RuntimeContext):

    def create_compressed(self, obj ) -> alfa.rt.Compressed:
        raise NotImplemented("Abstract method call")

    def create_compressed_from_bytes(self, obj: bytes ) -> alfa.rt.Compressed:
        raise NotImplemented("Abstract method call")

    def create_encrypted(self, obj ) -> alfa.rt.Encrypted:
        raise NotImplemented("Abstract method call")

    def create_encrypted_from_bytes(self, obj: bytes ) -> alfa.rt.Encrypted:
        raise NotImplemented("Abstract method call")

    def encrypt(self, input: bytes ) -> bytes:
        raise NotImplemented("Abstract method call")

    def decrypt(self, input: bytes ) -> bytes:
        raise NotImplemented("Abstract method call")
