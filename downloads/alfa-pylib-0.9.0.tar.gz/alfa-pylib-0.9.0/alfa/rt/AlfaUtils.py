import alfa.rt
import typing
import alfa.rt.model.DecisionTable__HitPolicy
import alfa.rt.DecisionExecTable
import alfa.rt.DecisionExecTableRow
# import alfa.rt.Try
# import alfa.rt.TryFailure


class AlfaUtils:

    @staticmethod
    def flatmap(v, path) :
        if len(path) == 0:
            return v
        elif isinstance(v, alfa.rt.Try.Try):
            if v.is_Result():
                return AlfaUtils.flatmap(v.Result, path)
            else:
                return None
        else:
            field = path[0]
            fieldVal = getattr(v,field)
            return AlfaUtils.flatmap(fieldVal, path[1:])

    @staticmethod
    def create_try_object(enclosed):
        return alfa.rt.Try.Try.create_Result(enclosed)

    @staticmethod
    def create_try_failure(message:str):
        tf = alfa.rt.TryFailure.TryFailure.new_builder()
        tf.Message = message
        return alfa.rt.Try.Try.create_Failure(tf.build())

    @staticmethod
    def execute_decision_table(inputs : typing.List[typing.Any],
                               hp : alfa.rt.model.DecisionTable__HitPolicy.DecisionTable__HitPolicy,
                               rules : typing.List[alfa.rt.DecisionExecTableRow.DecisionExecTableRow]) : #  causes circular ref -> alfa.rt.Try.Try[typing.List[typing.Any] ]:
        dt = alfa.rt.DecisionExecTable.DecisionExecTable( inputs, hp, rules)
        output = dt.execute()

        if len(output) > 0:
            return AlfaUtils.create_try_object(output)
        else:
            return AlfaUtils.create_try_failure("Decision table not satisfied")

