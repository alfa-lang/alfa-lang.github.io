
class AlfaServiceFactory:
    """Base class implemented by all Alfa Python service factory objects"""
    pass
