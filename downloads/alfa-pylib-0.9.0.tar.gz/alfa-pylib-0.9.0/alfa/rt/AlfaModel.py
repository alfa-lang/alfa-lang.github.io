
class AlfaModel:

    def __init__(self, fields):
        self.fields = fields

