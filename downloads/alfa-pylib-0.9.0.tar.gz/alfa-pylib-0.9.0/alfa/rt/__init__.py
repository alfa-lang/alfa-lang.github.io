# from .Encryted import Encrypted
# from .Compressed import Compressed
#
# from typing import TypeVar, Generic, Sequence
# from dataclasses import dataclass, Field
#
# from .JsonCodec import JsonCodec
# from .Randomizer import Randomizer
# from .ClassLoader import ClassLoader
# from .Validator import Validator
# from .AlfaDescriptor import AlfaDescriptor
# from .UnionUntypedCase import UnionUntypedCase
#
# name = "alfa.rt"
#
# __all__ = ['Validator', 'Compressed', 'JsonCodec', 'Randomizer', 'ClassLoader', 'AlfaDescriptor', 'UnionUntypedCase']
#
# COMT_co = TypeVar('COMT_co', covariant=True)
#
#
# @dataclass(frozen=True)
# class Compressed(Generic[COMT_co]):
#     item : COMT_co
#
#
# ENCT_co = TypeVar('ENCT_co', covariant=True)
#
#
# @dataclass(frozen=True)
# class Encrypted(Generic[ENCT_co]):
#     item : ENCT_co
#
