import abc

class AlfaLibrary(abc.ABC):
    """Base class implemented by all Alfa Python library     objects"""
    pass
