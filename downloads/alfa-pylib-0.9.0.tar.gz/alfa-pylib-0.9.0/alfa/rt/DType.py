#
# from alfa.rt.model.ScalarDataType import ScalarDataType
# from alfa.rt.model.ScalarType import ScalarType
# from alfa.rt.model.ListDataType import ListDataType
# from alfa.rt.model.SetDataType import SetDataType
# from alfa.rt.model.MapDataType import  MapDataType
# from alfa.rt.model.UdtMetaType import UdtMetaType
# from alfa.rt.model.UdtDataType import UdtDataType
# from alfa.rt.model.OptionalDataType import  OptionalDataType
#
# class DType:
#
#     @staticmethod
#     def string_type(mn,mx):
#         if not hasattr(DType, "_stringType"):
#             b = ScalarDataType.new_builder()
#             b.ScalarType = ScalarType.stringType
#             DType._stringType = b
#
#         return DType._stringType
#
#     @staticmethod
#     def int_type(mn,mx):
#         if not hasattr(DType, "_intType"):
#             b = ScalarDataType.new_builder()
#             b.ScalarType = ScalarType.intType
#             DType._intType = b
#
#         return DType._intType
#
#     @staticmethod
#     def boolean_type():
#         if not hasattr(DType, "_booleanType"):
#             b = ScalarDataType.new_builder()
#             b.ScalarType = ScalarType.booleanType
#             DType._booleanType = b
#
#         return DType._booleanType
#
#     @staticmethod
#     def double_type(mn,mx):
#         if not hasattr(DType, "_doubleType"):
#             b = ScalarDataType.new_builder()
#             b.ScalarType = ScalarType.doubleType
#             DType._doubleType = b
#
#         return DType._doubleType
#
#     @staticmethod
#     def date_type():
#         if not hasattr(DType, "_dateType"):
#             b = ScalarDataType.new_builder()
#             b.ScalarType = ScalarType.dateType
#             DType._dateType = b
#
#         return DType._dateType
#
#
#     @staticmethod
#     def list_type(comp_type):
#         b = ListDataType.new_builder()
#         b.ComponentType = comp_type
#         return b
#
#     @staticmethod
#     def param_type(name):
#         b = TypeParameterDataType.new_builder()
#         b.ParamName = name
#         return b
#
#     @staticmethod
#     def compress_type(comp_type):
#         b = CompressedDataType.new_builder()
#         b.ComponentType = comp_type
#         return b
#
#
#     @staticmethod
#     def udt_type(tname, udttype):
#         b = UdtDataType.new_builder()
#         b.FullyQualifiedName = tname
#         b.UdtType = udttype
#         return b
#
#
#     @staticmethod
#     def optional_type(comp_type):
#         b = OptionalDataType.new_builder()
#         b.ComponentType = comp_type
#         return b
#
#
#     @staticmethod
#     def map_type(k_type, v_type):
#         b = MapDataType.new_builder()
#         b.KeyType = k_type
#         b.ValueType = v_type
#         return b
#
#
