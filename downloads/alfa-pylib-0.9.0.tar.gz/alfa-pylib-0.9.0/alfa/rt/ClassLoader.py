import alfa.rt
from importlib import import_module

class ClassLoader:
    @staticmethod
    def load(type_name: str):
        ignored, py_file_name = type_name.rsplit(".", 1)
        class_name = py_file_name

        if py_file_name.endswith("$Key"):
            py_file_name = py_file_name.replace("$Key", "")
            class_name = py_file_name + "Key"

        clazz = getattr( import_module( type_name ), class_name )

        return clazz

    @staticmethod
    def is_alfa_udt_class(clz: type):
        return hasattr(clz, "_alfa_descriptor")

    @staticmethod
    def is_alfa_nativetype(clz: type):
        if hasattr(clz, '__bases__'):
            bases = clz.__bases__
            for base in bases:
                if base.__name__ == 'NativeAlfaObject':
                    return True

        return False

    @staticmethod
    def is_uri_class(t: type):
        return hasattr(t, '__module__') and t.__module__ == 'urllib.parse' and t.__name__ == 'ParseResult'

    @staticmethod
    def is_alfa_instanceof( obj, parent ):
        bases = obj.__class__.__bases__
        for base in bases:
            if base.__name__ == parent.__name__:
                return True

        return False
