
import abc
import dataclasses
import json
import functools
import typing
import datetime
import decimal
import uuid
import urllib.parse
import decimal
import isodate
import alfa.rt.AlfaDescriptor

import alfa.rt.AlfaObject
import alfa.rt.AlfaLibrary
import alfa.rt.AlfaKey
import alfa.rt.AlfaRecord
import alfa.rt.AlfaEntity
import alfa.rt.AlfaTrait
import alfa.rt.AlfaUnion

from alfa.rt.ClassLoader import ClassLoader

import alfa.rt.AlfaUtils
import alfa.rt.Validator
import alfa.rt.PathCreator
from alfa.rt.JsonCodec import JsonCodec
import alfa.rt.BuilderConfig
import alfa.rt.AlfaServiceFactory
import alfa.rt.AlfaService

from alfa.rt.TableCodec import TableCodec

import alfa.rt.model.UdtMetaType
from alfa.rt.model.ScalarDataType import ScalarDataType
from alfa.rt.model.ScalarType import ScalarType

import alfa.rt.DType

import alfa.test.Scenario
from alfa.rt.AlfaRandomizer import AlfaRandomizer


class ScenarioImpl(alfa.test.Scenario.Scenario):

    def __init__(self):
        self.randomiser = AlfaRandomizer([])

    def assertTrue(self, description : str, testBody : typing.Any) -> alfa.rt.UnionUntypedCase.UnionUntypedCase:
        pass

    def failsWith(self, description : str, testBody : typing.Any, expectedErrorMessage : str) -> alfa.rt.UnionUntypedCase.UnionUntypedCase:
        pass

    def failsOn(self, description : str, testBody : typing.Any, expectedErrorFieldPath : str) -> alfa.rt.UnionUntypedCase.UnionUntypedCase:
        pass

    def fails(self, description : str, testBody : typing.Any) -> alfa.rt.UnionUntypedCase.UnionUntypedCase:
        try:
            testBody()
            excp_thrown = False
        except:
            excp_thrown = True

        if not excp_thrown:
            raise Exception(f"Testcase '{description}' did not fail as expected")

    def withServiceResults(self, description : str, srv : str, results : typing.Mapping[str, typing.Sequence[str]]) -> alfa.rt.UnionUntypedCase.UnionUntypedCase:
        pass

    def given(self, description : str, data : alfa.rt.AlfaEntity.AlfaEntity) -> alfa.rt.UnionUntypedCase.UnionUntypedCase:
        pass

    def succeeds(self, description : str, testBody : typing.Any) -> alfa.rt.UnionUntypedCase.UnionUntypedCase:
        testBody()

    def randomWith(self, builder_obj) -> alfa.rt.AlfaObject.AlfaObject:
        return self.randomiser.random_with(builder_obj.__alfa_type__, builder_obj)

    def copyWith(self, original, builder_obj) -> alfa.rt.AlfaObject.AlfaObject:

        desc = type(original)._alfa_descriptor()
        fieldNames = set(desc.all_fields().keys())

        for field in fieldNames:
            found = hasattr(builder_obj, field)
            if not found or getattr(builder_obj, field ) is None:
                setattr(builder_obj, field, getattr( original, field ) )

        return builder_obj.build()

    def random(self, typeName : str) -> alfa.rt.AlfaObject.AlfaObject:
        return self.randomiser.random(typeName)

    def givenAll(self, description : str, path : str) -> alfa.rt.UnionUntypedCase.UnionUntypedCase:
        pass

    def loadObjectFromCsv(self, typeName : str, filePath : str) -> alfa.rt.AlfaObject.AlfaObject:
        data = self.loadObjectsFromCsv(typeName, filePath)
        return data[0]

    def loadObjectsFromCsv(self, typeName : str, filePath: str) -> typing.Sequence[alfa.rt.AlfaObject.AlfaObject]:
        contents = TableCodec.get_csv_contents(filePath)
        return self.__loadObjectsFromCsvString(typeName, contents)

    def __loadObjectsFromCsvString(self, typeName : str, contents: str) -> typing.Sequence[alfa.rt.AlfaObject.AlfaObject]:
        return TableCodec.csv_to_objects(typeName, contents)

class ScenarioFactoryImpl(alfa.rt.AlfaServiceFactory.AlfaServiceFactory):
    def create(self) -> ScenarioImpl:
        ScenarioImpl()

