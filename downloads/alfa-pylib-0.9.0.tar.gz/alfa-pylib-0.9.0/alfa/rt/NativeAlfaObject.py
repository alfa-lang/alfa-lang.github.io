import abc


class NativeAlfaObject(abc.ABC):
    """Base interface for a native Alfa object implementation."""
    @abc.abstractmethod
    def encode_to_string(self):
        pass

    @staticmethod
    def random_value():
        raise Exception("Random value generation not supported")
