from abc import abstractmethod
import alfa.rt.AlfaObject


class AlfaUnion(alfa.rt.AlfaObject.AlfaObject):
    """Base class implemented by all Alfa unions"""
    @abstractmethod
    def case_name(self):
        """The name of the union case for this value"""
        pass

    @abstractmethod
    def case_value(self):
        """The value assigned to this union case"""
        pass