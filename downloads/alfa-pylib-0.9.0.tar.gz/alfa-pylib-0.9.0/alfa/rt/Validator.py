from typing import TypeVar, Generic, Sequence
import dataclasses
import alfa.rt
import alfa.rt.UnionUntypedCase
import datetime


class Validator:


    @staticmethod
    def validateWithPattern( pathLambda, str_value, regex_pattern ):
        import re
        pattern = re.compile(regex_pattern)

        if not pattern.match(str_value):
            raise Exception(f"{pathLambda().field} value '{str_value}' does not conform to the pattern {regex_pattern}")

    @staticmethod
    def validateCollectionSize( pathLambda, valType, vector, minVal, maxVal ):
        if minVal is not None and len(vector) < minVal:
            raise Exception(f"{pathLambda().field} {valType} size {len(vector)} cannot be smaller than minimum {minVal}")

        if maxVal is not None and len(vector) > maxVal:
            raise Exception(f"{pathLambda().field} {valType} size {len(vector)} cannot be greater than maximum {maxVal}")

    @staticmethod
    def validateScalarRange( pathLambda, valType, value, minVal, maxVal ):
        if minVal is not None and value < minVal:
            raise Exception(f"{pathLambda().field} {valType} {value} cannot be smaller than minimum {minVal}")

        if maxVal is not None and value > maxVal:
            raise Exception(f"{pathLambda().field} {valType} {value} cannot be greater than maximum {maxVal}")

    @staticmethod
    def validate(obj: object, field_defs: Sequence[dataclasses.Field]):
        Validator._validate_mandatory_fields( obj, field_defs)
        Validator._validate_fieldtypes( obj, field_defs)

    @staticmethod
    def _validate_mandatory_fields( obj : object, field_defs: Sequence[dataclasses.Field]):
        for f in field_defs:
            val = getattr(obj, f.name)
            t = f.type

            if (val is not None) or Validator._is_optional(t):
                continue
            else:
                raise Exception("Mandatory field not set " + f.name)

    @staticmethod
    def _is_optional(t):
        opt = str(t).startswith("typing.Union[") and len(t.__args__) == 2 and t.__args__[1] == type(None)
        return opt

    @staticmethod
    def _validate_fieldtypes(obj: object, field_defs: Sequence[dataclasses.Field]):
        for f in field_defs:
            val = getattr(obj, f.name)
            field_t = f.type

            # mandatory would have been reported before
            if val is None:
                continue

            try:
                Validator.validate_datatype(val, field_t)
            except Exception as e:
                raise TypeError('Error in field ' + f.name + ':' + str(f.type) + '.\n\tType mismatch in value ' + str(val) + '.\n\t' + str( e ))

    @staticmethod
    def validate_datatype(val: object, t: type):
        valtype = type(val)

        if valtype == t:
            return

        elif isinstance(val, int) and t == float:
            return

        elif type(t) == TypeVar:
            return
        else:
            t_str = str(t)

            if Validator._is_optional(t):
                if val is None:
                    return
                else:
                    args = t.__args__
                    return Validator.validate_datatype(val, args[0])

            elif t_str.startswith("alfa.rt.Try.Try["):
                args = t.__args__
                # Not handling errors yet
                if val.is_Result():
                    Validator.validate_datatype(val.Result, args[0])

                if val.is_Failure():
                    Validator.validate_datatype(val.Failure, alfa.rt.TryFailure.TryFailure)

                return

            elif t_str.startswith("alfa.rt.Either.Either["):
                args = t.__args__
                if val.is_Left():
                    Validator.validate_datatype(val.Left, args[0])

                if val.is_Right():
                    Validator.validate_datatype(val.Right, args[1])

                return

            elif t_str.startswith("alfa.rt.Compressed.Compressed["):
                return

            elif t_str.startswith("alfa.rt.Encrypted.Encrypted["):
                return

            elif t_str.startswith("typing.Mapping[") and valtype == dict:
                args = t.__args__
                for e in val:
                    Validator.validate_datatype(e, args[0])
                    Validator.validate_datatype(val[e], args[1])
                return

            elif t_str.startswith("typing.Sequence[") and valtype == list:
                args = t.__args__
                for e in val:
                    Validator.validate_datatype(e, args[0])
                return

            elif t_str.startswith("typing.Set[") and (valtype == set or valtype == frozenset):
                args = t.__args__
                for e in val:
                    Validator.validate_datatype(e, args[0])
                return

            elif t == alfa.rt.UnionUntypedCase.UnionUntypedCase and val == "":
                return

            elif t == datetime.date and valtype != datetime.date:
                raise TypeError('Expected date got ' + t_str)

            elif t == datetime.datetime and valtype != datetime.datetime:
                raise TypeError('Expected datetime got ' + t_str)

            elif t == datetime.time and valtype != datetime.time:
                raise TypeError('Expected time got ' + t_str)

            elif issubclass(valtype, t):
                return

            # else:
            #     for clz in valtype.__bases__:
            #         if clz == t:
            #             return

        err = "Type mismatch. Declared Type:" + t_str + " Value Type: " + str(type(val)) + \
              "\nValue:" + str(val)

        raise TypeError( err )
