import decimal
import urllib.parse
import uuid
from datetime import date
from datetime import datetime
from datetime import time
from decimal import Decimal
from typing import Mapping
from typing import Optional
from typing import Sequence
from typing import Set

import isodate
import math
import functools

import alfa.rt

# from alfa.rt.AlfaEntity import AlfaEntity
# from alfa.rt.AlfaKey import AlfaKey
# from alfa.rt.Either import alfa.rt.Either
# from alfa.rt.Try import alfa.rt.Try
# from alfa.rt.Try import alfa.rt.Try__Result


class AlfaBuiltinFunctions:

    def __init__(self):
        pass

    def max(self, vectorOrScalar, scalarOrVectorCompareFn = None ):
        if isinstance(vectorOrScalar, list):
            if scalarOrVectorCompareFn is None:
                return max(vectorOrScalar)
            else:
                return max(vectorOrScalar, key=functools.cmp_to_key(scalarOrVectorCompareFn) )

        elif isinstance(vectorOrScalar, set):
            return max(vectorOrScalar)

        else:
            return min(vectorOrScalar, scalarOrVectorCompareFn)

    def min(self, vectorOrScalar, scalarOrVectorCompareFn = None ):
        if isinstance(vectorOrScalar, list):
            if scalarOrVectorCompareFn is None:
                return min(vectorOrScalar)
            else:
                return min(vectorOrScalar, key=functools.cmp_to_key(scalarOrVectorCompareFn) )

        elif isinstance(vectorOrScalar, set):
            return min(vectorOrScalar)

        else:
            return min(vectorOrScalar, scalarOrVectorCompareFn)


    def filter( self, listSetOrDict: Sequence, predFunction) ->  Sequence:
        if isinstance(listSetOrDict, dict):
            return dict( filter(lambda x: predFunction(x[0], x[1]), listSetOrDict.items()) )
        elif isinstance(listSetOrDict, list):
            return list( filter(lambda x: predFunction(x), listSetOrDict) )
        elif isinstance(listSetOrDict, set):
            return set( filter(lambda x: predFunction(x), list(listSetOrDict)) )
        else:
            raise Exception("Unsupported arg to filter")

    # left 1. string, either, list
    def left( self, strEitherOrList: str, size = 0) -> str:
        if isinstance(strEitherOrList, str):
            return strEitherOrList[0:size]
        elif isinstance(strEitherOrList, Sequence):
            return strEitherOrList[0:size]
        elif isinstance(strEitherOrList, alfa.rt.Either.Either):
            return strEitherOrList.Left
        else:
            raise Exception("Cannot access left of " + str(type(strEitherOrList)))

    def isRight(self, obj):
        from alfa.rt.Either import Either__Right
        return isinstance(obj, Either__Right)

    def isLeft(self, obj):
        from alfa.rt.Either import Either__Left
        return isinstance(obj, Either__Left)

    def right( self, strEitherOrList: str, size = 0) -> str:
        if isinstance(strEitherOrList, str):
            return strEitherOrList[(size * -1):]
        elif isinstance(strEitherOrList, list):
            return strEitherOrList[(size * -1):]
        elif isinstance(strEitherOrList, alfa.rt.Either.Either):
            return strEitherOrList.Right
        else:
            raise Exception("Cannot access right of " + str(type(strEitherOrList)))

    def toMap( self, setOrList, keyFunction, valFunction ) ->  Mapping:
        res = {}
        for e in setOrList:
            res[keyFunction(e)] = valFunction(e)
        return res

    def isNone( self, optVal:  Optional ) -> bool:
        return optVal is None

    def isSome( self, optVal:  Optional ) -> bool:
        return optVal is not None

    def keyOf( self, entityObj ) :  # causes circular ref : alfa.rt.AlfaEntity ): -> alfa.rt.AlfaKey:
        return entityObj.__key__

    def some( self, a1 ) ->  Optional:
        return a1

    def toDate( self, dateStrOrDatetime: str ) -> date:
        return datetime.fromisoformat(str(dateStrOrDatetime)).date()

    def toDatetime( self, datetimeAsStr: str ) -> datetime:
        if isinstance(datetimeAsStr, str) and len(datetimeAsStr) == 10:
            datetimeAsStr += " 00:00:00.000"
        elif isinstance(datetimeAsStr, date):
            datetimeAsStr = str(datetimeAsStr) + " 00:00:00.000"
        return datetime.fromisoformat(datetimeAsStr)

    def toTime( self, timeAsStr: str ) -> time:
        return time.fromisoformat(timeAsStr)

    def toDecimal( self, strOrNumVal: str ) -> Decimal:
        return Decimal(strOrNumVal)

    def toDouble( self, strOrNumVal: int ) -> float:
        return float(strOrNumVal)

    def toDuration( self, strVal: str ) -> isodate.Duration:
        d = isodate.parse_duration(strVal)
        return isodate.Duration(days=d.days, seconds=d.seconds)

    def toInt( self, strVal: str ) -> int:
        return int(strVal)

    def toList( self, setVal: Set) ->  Sequence:
        return setVal

    def toSet( self, listVal: Sequence) ->  Set:
        return set(listVal)

    def newEitherLeft( self, leftVal ) : # causes circular ref -> alfa.rt.Either:
        from alfa.rt.Either import Either__Left
        return Either__Left(leftVal)

    def newEitherRight( self, rightVal ) : # causes circular ref-> alfa.rt.Either:
        from alfa.rt.Either import Either__Right
        return Either__Right(rightVal)

    def newTryValue( self, result ) : # causes circular ref-> alfa.rt.Try:
        return alfa.rt.Try.Try.create_Result(result)

    def newTryFailure( self, failMsg ) : # causes
        from alfa.rt.TryFailure import TryFailure
        tf = alfa.rt.TryFailure.TryFailure(failMsg, None, None)# circular ref ->  alfa.rt.Try:
        return alfa.rt.Try.Try.create_Failure(tf)

    def isTryFailure(self, tf):
        return tf.is_Failure()

    def newUUID(self) -> uuid.UUID:
        return uuid.uuid4()

    def now(self) -> time:
        return datetime.now()

    def today(self) -> date:
        return datetime.today()

    def year( self, a1: datetime ) -> int:
        return a1.year

    def year( self, a1: date ) -> int:
        return a1.year

    def month( self, a1: datetime ) -> int:
        return a1.month

    def month( self, a1: date ) -> int:
        return a1.month

    def day( self, dateDatetimeOrDuration ) -> int:
        if isinstance(dateDatetimeOrDuration, date) or isinstance(dateDatetimeOrDuration, datetime):
            return dateDatetimeOrDuration.day
        else:
            return dateDatetimeOrDuration.tdelta.days

    def weekday( self, a1: datetime ) -> int:
        return a1.weekday()

    def weekday( self, a1: date ) -> int:
        return a1.weekday()

    def hour( self, hourObj ) -> int:
        return hourObj.hour

    def minute( self, minuteObj ) -> int:
        return minuteObj.minute

    def second( self, secondObj ) -> int:
        return secondObj.second

    def millisecond( self, millisecondObj ) -> int:
        return millisecondObj.microsecond / 1000

    # TODO
    def dateDiff( self, d1: date , d2: date ) -> int:
        return (d2 - d1).days

    def add( self, setOrList, newEntry ) -> None:
        if isinstance(setOrList, list):
            setOrList.append(newEntry)
        elif isinstance(setOrList, set):
            setOrList.add(newEntry)
        else:
            raise Exception("Unsupported arg")

    def get( self, optOrTryOrMapOrList, mapKeyOrListIndex=None):
        from alfa.rt.Try import Try__Result

        if isinstance(optOrTryOrMapOrList, dict) or isinstance(optOrTryOrMapOrList, list):
            return optOrTryOrMapOrList[mapKeyOrListIndex]
        elif isinstance(optOrTryOrMapOrList, Try__Result):
            return optOrTryOrMapOrList.Result
        elif optOrTryOrMapOrList is None:
            raise Exception("Cannot get() on None")
        else:
            return optOrTryOrMapOrList


    def put( self, mapVal: Mapping, key, val) -> None:
        mapVal[key] = val

    def toString( self, dateVal: date ) -> str:
        return dateVal.isoformat()

    def toString( self, a1: bool ) -> str:
        return str(a1)

    def toString( self, a1: datetime ) -> str:
        return str(a1)

    def toString( self, a1: time ) -> str:
        return str(a1)

    def toString( self, a1: urllib.parse.ParseResult ) -> str:
        return

    def toString( self, intVal: int ) -> str:
        return str(intVal)

    def toString( self, a1: float ) -> str:
        return str(a1)

    def toString( self, intVal: int ) -> str:
        return str(intVal)

    def toString( self, strVal: str ) -> str:
        return str(strVal)

    def toString( self, a1: decimal.Decimal ) -> str:
        return str(a1)

    def values( self, a1: Mapping) ->  Sequence:
        return list(a1.values())

    def abs( self, num_value ):
        return abs(num_value)

    def sqrt( self, a1: float ) -> float:
        return math.sqrt(a1)

    def log( self, a1: float ) -> float:
        return math.log(a1)

    def indexOf( self, listOrStr: Sequence, item ) -> int:
        return listOrStr.index(item)

    def isEmpty( self, mapOrSetOrListOrString ) -> bool:
        return len(mapOrSetOrListOrString) == 0

    def startsWith( self, strVal: str, start: str ) -> bool:
        return strVal.startswith(start)

    def endsWith( self, strVal: str, ends: str ) -> bool:
        return strVal.endswith(ends)

    def substring( self, strVal: str, start: int , end=-1 ) -> str:
        if end == -1:
            return strVal[start:]
        else:
            return strVal[start:end]


    def contains( self, collection, item ) -> bool:
        return item in collection

    def replaceAll( self, strVal: str, oldStr: str , newStr: str ) -> str:
        return strVal.replace(oldStr, newStr)

    def split( self, strVal: str, separator: str ) ->  Sequence:
        return strVal.split(separator)

    def compare( self, l , r ) -> int:
        return (l > r) - (l < r)

    def delete( self, listOrSetOrDict, item ):
        if isinstance(listOrSetOrDict, dict):
            listOrSetOrDict.pop(item)
        elif isinstance(listOrSetOrDict, list):
            listOrSetOrDict.pop(item)
        elif isinstance(listOrSetOrDict, set):
            listOrSetOrDict.remove(item)
        else:
            raise Exception("Unsupported arg to delete")


    def timestamp(self) -> datetime:
        return datetime.now()

    def keys( self, a1: Mapping) ->  Set:
        return a1.keys()

    # TODO
    def query( self, entity_name: str, predFunction) -> Sequence:
        return

    def toLower( self, strVal: str ) -> str:
        return strVal.lower()

    def sort( self, listOrSetVal: Sequence, fn = None ) ->  Sequence:
        if fn is None:
            return sorted( listOrSetVal )
        else:
            return sorted( listOrSetVal, key=functools.cmp_to_key(fn) )


    # TODO
    def lookup( self, entityType, keyObj ) : # causes circular ref : alfa.rt.AlfaKey.AlfaKey ) ->  Optional[alfa.rt.AlfaEntity.AlfaEntity]:
        return

    def ceil( self, a1: float ) -> float:
        return math.ceil(a1)

    def floor( self, a1: float ) -> float:
        return math.floor(a1)

    def round( self, a1: float ) -> int:
        return round(a1)

    # TODO
    def random(self) -> float:
        return

    def map( self, listSetOrDict: Mapping, keyOrElementFn, valFn=None ):
        if isinstance(listSetOrDict, dict):
            return dict( map(lambda x: ( keyOrElementFn(x[0],x[1]), valFn(x[0], x[1]) ), listSetOrDict.items()) )
        elif isinstance(listSetOrDict, list):
            return list( map(lambda x: keyOrElementFn(x), listSetOrDict) )
        elif isinstance(listSetOrDict, set):
            return set( map(lambda x: keyOrElementFn(x), list(listSetOrDict)) )
        else:
            raise Exception("Unsupported arg to map")

    # TODO
    def reduce( self, listSetOrDict, accumVal, fn ) :
        if isinstance(listSetOrDict, dict):
            return functools.reduce( lambda acc, kv : fn(acc, kv[0], kv[1]), listSetOrDict.items(), accumVal )

        elif isinstance(listSetOrDict, list) or isinstance(listSetOrDict, set):
            return functools.reduce(fn, listSetOrDict, accumVal)

        else:
            raise Exception("Unsupported arg to reduce")

    # TODO
    def toUpper( self, strVal: str ) -> str:
        return strVal.upper()

    # TODO
    def len( self, obj_with_len) -> int:
        return len(obj_with_len)

    # TODO
    def len( self, setVal: Set ) -> int:
        return len(setVal)


# a = AlfaBuiltinFunctions()
# print(a.toDate("2020-12-12"))
#
# print( a.toDecimal(101) )
#
#
