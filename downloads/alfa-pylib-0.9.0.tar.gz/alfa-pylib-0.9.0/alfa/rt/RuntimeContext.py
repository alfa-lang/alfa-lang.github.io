import abc
import gzip
from alfa.rt.AlfaBuiltinFunctions import AlfaBuiltinFunctions

class RuntimeContext:
    """Implements the Alfa runtimes for compression and encryption. Alternative implementations can be provided to override the default implementation."""

    builtins : AlfaBuiltinFunctions

    def __init__(self):
        self.builtins = AlfaBuiltinFunctions()

    def encrypt(self, input_data: bytes) -> bytes:
        """Encrypt the given byte[]"""
        raise Exception("RuntimeContext.encrypt() not yet supported")
        pass

    def decrypt(self, input_data: bytes) -> bytes:
        """Decrypt the given byte[]"""
        raise Exception("RuntimeContext.decrypt() not yet supported")
        pass

    def compress(self, input_data: bytes) -> bytes:
        """Compress the input bytes using a compression implementation"""
        return gzip.compress(input_data)

    def uncompress(self, input_data: bytes) -> bytes:
        """Decompress the input bytes using the reverse of the compression implementation"""
        return gzip.decompress(input_data)

