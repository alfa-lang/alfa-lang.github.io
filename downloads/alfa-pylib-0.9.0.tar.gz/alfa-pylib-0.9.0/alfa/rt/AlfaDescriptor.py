import dataclasses
import typing
import alfa.rt.model.UdtMetaType as UdtMetaType
from alfa.rt.JsonCodec import JsonCodec
from alfa.rt.model.IDataType import IDataType
from alfa.rt.model.Field import Field

class AlfaDescriptor:
    _name: str
    _alfa_type: UdtMetaType.UdtMetaType
    _python_decl_fields: typing.Mapping[str, dataclasses.Field]
    _alfa_desc_fields : typing.Mapping[str, Field]
    _alfa_to_python_fields : typing.Mapping[str, str]

    def __init__(self, name, alfa_type, alfa_clz, field_types):
        self._name = name
        self._alfa_type = alfa_type
        self._python_decl_fields = {}
        self._alfa_desc_fields = {}
        self._alfa_to_python_fields = {}

        for f in field_types:
            alfa_field : Field = JsonCodec.from_json(field_types[f])
            self._alfa_desc_fields[f] = alfa_field
            self._alfa_to_python_fields[alfa_field.Name] = field_types[f]

        if dataclasses.is_dataclass(alfa_clz):
            for f in dataclasses.fields(alfa_clz):
                self._python_decl_fields[f.name] = f

    def field_alfa_type(self, fname):
        if fname in self._alfa_desc_fields:
            return self._alfa_desc_fields[fname].DataType
        else:
            return None

    def __str__(self):
        return "Descriptor name:" + self._name + \
               " type:" + str( self._alfa_type ) + \
               " " + str( self._python_decl_fields.values() )

    def name(self):
        return self._name

    def alfa_type(self):
        return self._alfa_type

    def all_fields(self):
        return self._python_decl_fields

