from alfa.rt.AlfaObject import AlfaObject


class AlfaKey(AlfaObject):
    """Base class implemented by all Alfa Python objects corresponding to keys in Alfa."""
    pass
