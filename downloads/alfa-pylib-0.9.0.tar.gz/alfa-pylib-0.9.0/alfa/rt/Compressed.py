import typing
# from alfa.rt.JsonCodec import JsonCodec

from dataclasses import dataclass
from alfa.rt.JsonCodec import JsonCodec
import json
# import gzip
from alfa.rt.BuilderConfig import BuilderConfig

COMPT_co = typing.TypeVar('COMPT_co', covariant=True)


@dataclass(frozen=True)
class Compressed(typing.Generic[COMPT_co]):
    """Representation of a compressed Alfa type value."""
    encoded: bytes
    encoded_type: type

    def get_value(self, builder_config: BuilderConfig) -> COMPT_co:
        """Get the underlying value represented by this instance"""
        decompressed_bytes = builder_config.runtime_context.uncompress(self.encoded)
        # decompressed_bytes = gzip.decompress(self.encoded)
        json_str = decompressed_bytes.decode("utf-8")
        obj = json.loads(json_str)
        enclosed_obj = JsonCodec._from_dict_value(obj, self.encoded_type)
        return enclosed_obj

    @staticmethod
    def from_obj_value(builder_config: BuilderConfig, unencoded_obj: COMPT_co, unencoded_obj_type: type):
        """Create a Compressed value given an underlying value"""
        as_obj = JsonCodec._to_dict_value(unencoded_obj, unencoded_obj_type)
        json_str = json.dumps(as_obj)
        compbytes = builder_config.runtime_context.compress(bytes(json_str, 'utf-8'))
        # compbytes = gzip.compress(bytes(json_str, 'utf-8'))
        return Compressed(compbytes, unencoded_obj_type)

    @staticmethod
    def from_bytes_value(encoded_bytes: bytes, unencoded_obj_type: type):
        """Create a Compressed value given a byte[]"""
        return Compressed(encoded_bytes, unencoded_obj_type)

