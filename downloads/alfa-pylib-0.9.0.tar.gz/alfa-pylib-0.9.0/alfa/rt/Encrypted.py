import typing
# from alfa.rt.JsonCodec import JsonCodec

from dataclasses import dataclass
from alfa.rt.JsonCodec import JsonCodec
import json
# import gzip
from alfa.rt.BuilderConfig import BuilderConfig

ENCT_co = typing.TypeVar('ENCT_co', covariant=True)


@dataclass(frozen=True)
class Encrypted(typing.Generic[ENCT_co]):
    """Representation of a Encrypted Alfa type value."""
    encoded: bytes
    encoded_type: type

    def get_value(self, builder_config: BuilderConfig) -> ENCT_co:
        """Get the underlying value represented by this instance"""
        deEncrypted_bytes = builder_config.runtime_context.decrypt(self.encoded)
        # deEncrypted_bytes = gzip.decompress(self.encoded)
        json_str = deEncrypted_bytes.decode("utf-8")
        obj = json.loads(json_str)
        enclosed_obj = JsonCodec._from_dict_value(obj, self.encoded_type)
        return enclosed_obj

    @staticmethod
    def from_obj_value(builder_config: BuilderConfig, unencoded_obj: ENCT_co, unencoded_obj_type: type):
        """Create a Encrypted value given an underlying value"""
        as_obj = JsonCodec._to_dict_value(unencoded_obj, unencoded_obj_type)
        json_str = json.dumps(as_obj)
        compbytes = builder_config.runtime_context.encrypt(bytes(json_str, 'utf-8'))
        # compbytes = gzip.compress(bytes(json_str, 'utf-8'))
        return Encrypted(compbytes, unencoded_obj_type)

    @staticmethod
    def from_bytes_value(encoded_bytes: bytes, unencoded_obj_type: type):
        """Create a Encrypted value given a byte[]"""
        return Encrypted(encoded_bytes, unencoded_obj_type)

