import typing

class DecisionExecTableRow:
    def __init__(self, rules : typing.List[typing.Any], output : typing.Any):
        self.rules = rules
        self.output = output

    def evaluate(self, ruleInputs : typing.List[typing.Any]) -> typing.Optional[typing.Any]:
        for i in range(len(ruleInputs)):
            inputs = ruleInputs[i]
            ruleLambda = self.rules[i]
            success = ruleLambda(inputs)
            if not success:
                return None

        return self.output



        # for (int i = 0 i < ruleInputs.size() i++):
        #     Function<Object, Boolean> rule = rules.get(i)
        #     Boolean pass = rule.apply(ruleInputs.get(i))
        #     if ( ! pass )
        #         return Optional.empty()
        #
        #
        # return Optional.of( output )
