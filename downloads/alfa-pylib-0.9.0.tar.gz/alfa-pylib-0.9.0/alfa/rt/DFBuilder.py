import pandas as pd
from alfa.rt.TableCodec import TableCodec

class DFBuilder:

    @staticmethod
    def from_alfa_object(alfa_obj):
        af = TableCodec(alfa_obj)
        tbl = af.to_table()
        return DFBuilder.from_table(tbl)

    @staticmethod
    def from_alfa_objects(alfa_objs_list):
        df_per_objs = []
        for alfa_obj in alfa_objs_list:
            af = TableCodec(alfa_obj)
            tbl = af.to_table()
            df = DFBuilder.from_table(tbl)
            df_per_objs.append(df)

        return pd.concat(df_per_objs)

    @staticmethod
    def from_table(table):

        data = {}
        for c in table.columns:
            col_values = []
            data[c] = col_values
            for r in table.rows:
                cell = r.get_value(c)
                col_values.append(cell)

        df = pd.DataFrame(data)
        return df
