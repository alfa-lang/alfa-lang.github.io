import pandas as pd
from alfa.rt.TableCodec import TableCodec

class DFBuilder:

    @staticmethod
    def from_alfa_object(alfa_obj):
        af = TableCodec(alfa_obj)
        tbl = af.to_table()
        return DFBuilder.from_table(tbl)

    @staticmethod
    def from_alfa_objects(alfa_objs_list):
        table_per_objs = []
        for alfa_obj in alfa_objs_list:
            af = TableCodec(alfa_obj)
            tbl = af.to_table()
            table_per_objs.append(tbl)

        rows = []
        for table in table_per_objs:
            data = {}
            for c in table.columns:
                col_values = []
                data[c] = col_values
                for r in table.rows:
                    cell = r.get_value(c)
                    col_values.append(cell)

            rows.append(data)

        df = pd.DataFrame(rows)
        return df

    @staticmethod
    def from_table(table):

        data = {}
        for c in table.columns:
            col_values = []
            data[c] = col_values
            for r in table.rows:
                cell = r.get_value(c)
                col_values.append(cell)

        df = pd.DataFrame(data)
        return df
