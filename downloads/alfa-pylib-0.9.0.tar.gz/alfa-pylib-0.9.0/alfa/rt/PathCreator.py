class PathCreator:
    def __init__(self, fieldName):
        self.field = fieldName

    def mapEntryElement( self, mapentry ):
        self.mapentry = mapentry
        return self

    def listIdxElement(self, index) :
        self.index = index
        return self

    def setEntryElement(self, entry) :
        self.entry = entry
        return self

    def scalarElement(self, entry):
        self.entry = entry
        return self
