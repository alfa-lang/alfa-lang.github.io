from alfa.rt.AlfaObject import AlfaObject


class AlfaRecord(AlfaObject):
    """Base class implemented by all Alfa Python objects corresponding to records in Alfa."""
    pass
