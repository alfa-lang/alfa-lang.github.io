class UnionUntypedCase:
    def __eq__(self, other):
        return isinstance(other, UnionUntypedCase)