import alfa.rt
import random
import string
import datetime
import decimal
import uuid
import urllib.parse
import alfa.rt.model.UdtMetaType as UdtMetaType
from alfa.rt.Validator import Validator
from alfa.rt.ClassLoader import ClassLoader

import isodate
from alfa.rt.BuilderConfig import BuilderConfig

class AlfaRandomizer:

    _total_rand_entries_ = 5

    def __init__(self, all_type_names):
        self.all_type_names = all_type_names

    def _rand_value(self, t: type, alfatype):
        t_str = str(t)


        if Validator._is_optional(t):
            if random.randint(0, 9) == 0:
                return None
            else:
                args = t.__args__
                return self._rand_value(args[0], alfatype.ComponentType)

        elif t_str.startswith("alfa.rt.Try.Try["):
            args = t.__args__
            # Not handling errors yet
            val = self._rand_value(args[0], alfatype.ComponentType)
            return alfa.rt.Try.Try.create_Result(val)

        elif t_str.startswith("alfa.rt.Either.Either["):
            args = t.__args__
            # Not handling errors yet
            l = self._rand_value(args[0], alfatype.LeftComponentType)
            return alfa.rt.Either.Either.create_Left(l)

        elif t_str.startswith("typing.Mapping["):
            args = t.__args__
            m = {}
            for i in range(self._total_rand_entries_):
                k = self._rand_value(args[0], alfatype.KeyType)
                v = self._rand_value(args[1], alfatype.ValueType)
                m[k] = v

            return m

        elif t_str.startswith("typing.Sequence["):
            args = t.__args__
            lst = []
            for i in range(self._total_rand_entries_):
                lst.append(self._rand_value(args[0], alfatype.ComponentType))
            return lst

        elif t_str.startswith("typing.Union["):
            args = t.__args__
            return self._rand_value(args[0])

        elif t_str.startswith("alfa.rt.Compressed.Compressed["):
            args = t.__args__
            inner = self._rand_value(args[0], alfatype.ComponentType)
            return alfa.rt.Compressed.Compressed.from_obj_value(BuilderConfig(), inner,args[0])


        elif t_str.startswith("alfa.rt.Encrypted.Encrypted["):
            args = t.__args__
            inner = self._rand_value(args[0], alfatype.ComponentType)
            return alfa.rt.Encrypted.Encrypted.from_obj_value(BuilderConfig(), inner,args[0])
            # return alfa.rt.Encrypted.Encrypted(inner)

        elif t_str.startswith("typing.Set["):
            args = t.__args__
            lst = set()
            for i in range(self._total_rand_entries_):
                lst.add(self._rand_value(args[0], alfatype.ComponentType))
            return lst

        elif t == int:
            start = alfatype.min.intValue if alfatype.min is not None else 0
            end = alfatype.max.intValue if alfatype.max is not None else 100
            return random.randint(start, end)

        elif t == bool:
            return random.randint(0, 1) == 0

        elif t == float:
            start = alfatype.min.doubleValue if alfatype.min is not None else 0.0
            end = alfatype.max.doubleValue if alfatype.max is not None else 100.0

            return random.uniform(start, end)

        elif t == uuid.UUID:
            return uuid.uuid4()

        elif t == datetime.datetime:
            y = random.randint(1990, 2100)
            m = random.randint(1, 12)
            d = random.randint(1, 28)
            h = random.randint(1, 12)
            return datetime.datetime(y,m,d, h,0,0)

        elif t == datetime.time:
            start = alfatype.min.timeValue if alfatype.min is not None else datetime.time(1,0,0)
            end = alfatype.max.timeValue if alfatype.max is not None else datetime.time(23,59,59)

            dateTimeS = datetime.datetime.combine(datetime.date.today(), start)
            dateTimeE = datetime.datetime.combine(datetime.date.today(), end)

            dateTimeDifference = dateTimeE - dateTimeS
            upper = int(dateTimeDifference.total_seconds())
            randSecs = random.randint(1, upper)
            random_datetime = dateTimeS + datetime.timedelta(seconds=randSecs)
            return random_datetime.time()

        elif t == isodate.Duration:
            m = random.randint(1, 5)

            return isodate.Duration(days=m)

        elif t == datetime.date:
            start_date = alfatype.min.dateValue if alfatype.min is not None else datetime.date(1900,1,1)
            end_date = alfatype.max.dateValue if alfatype.max is not None else datetime.date(2100,12,31)

            time_between_dates = end_date - start_date
            days_between_dates = time_between_dates.days
            random_number_of_days = random.randrange(days_between_dates)
            random_date = start_date + datetime.timedelta(days=random_number_of_days)

            return random_date

        elif t == decimal.Decimal:
            p = alfatype.precision.precision if alfatype.precision is not None else 6
            d = random.uniform(1.0, 100.0)
            return round(decimal.Decimal(d), p)

        elif t == alfa.rt.UnionUntypedCase.UnionUntypedCase:
            return alfa.rt.UnionUntypedCase.UnionUntypedCase()

        elif t == str:
            rand_str = ''.join(random.choices(string.ascii_lowercase, k=self.range_constraint(alfatype)))
            return rand_str

        elif t == bytes:
            return ''.join(random.choices(string.ascii_uppercase, k=self._total_rand_entries_)).encode('utf-8')

        elif ClassLoader.is_alfa_udt_class(t):
            class_name = t._alfa_descriptor().name()
            return self.random(class_name)

        elif ClassLoader.is_alfa_nativetype(t):
            rnd = t.random_value()
            return rnd

        elif ClassLoader.is_uri_class(t):
            return urllib.parse.urlparse("http://192.168.0.1:" + str(random.randint(1000,9999)) )

        else:
            raise Exception( 'unhandled type to randomize : ' + t_str )

    def random(self, type_name: str, builder_config = BuilderConfig() ):
        return self.random_with(type_name, builder_config, None)

    def random_with(self, type_name: str, builder_config = BuilderConfig(), builder_obj = None):
        clazz = ClassLoader.load(type_name)
        desc = clazz._alfa_descriptor()

        if desc.alfa_type() == UdtMetaType.UdtMetaType.traitType:
            for tr in self.all_type_names:
                trImpl = ClassLoader.load(tr)
                if issubclass(trImpl,clazz):
                    return self.random(tr)
            raise Exception("No implemenation of type found " + type_name )

        if desc.alfa_type() == UdtMetaType.UdtMetaType.unionType:
            fs = desc.all_fields()
            fname, field = random.choice(list(fs.items()))

            # Union fields are optional, get a value for the non optional type
            union_field_type = field.type.__args__[0]
            aft = desc.field_alfa_type(fname)

            v = clazz.create( fname, self._rand_value(union_field_type, aft))
            return v

        if desc.alfa_type() == UdtMetaType.UdtMetaType.enumType:
            memDef = clazz(random.randint(0, len( clazz.__members__) - 1 ))
            return memDef

        else:
            builder = clazz.new_builder(builder_config)

            for f in desc.all_fields():
                if hasattr(builder_obj, f):
                    v = getattr(builder_obj, f)
                else:
                    ft = desc.all_fields().get(f).type
                    aft = desc.field_alfa_type(f)

                    v = self._rand_value(ft, aft)

                setattr(builder, f, v)

            return builder.build()

    def range_constraint(self, alfatype):
        min = alfatype.min.intValue if alfatype.min is not None and alfatype.min.intValue is not None else 1
        max = alfatype.max.intValue if alfatype.max is not None and alfatype.max.intValue is not None else 5

        return random.randint(min, max)
