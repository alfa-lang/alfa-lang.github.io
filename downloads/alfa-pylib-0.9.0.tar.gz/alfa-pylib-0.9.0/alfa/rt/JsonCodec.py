import json
import alfa.rt
from importlib import import_module
import datetime
import uuid
import urllib.parse
import base64
import decimal
import gzip
import typing

import isodate

from alfa.rt.ClassLoader import ClassLoader
from alfa.rt.Validator import Validator
from alfa.rt.UnionUntypedCase import UnionUntypedCase
from alfa.rt.model.UdtMetaType import UdtMetaType
from alfa.rt.BuilderConfig import BuilderConfig

class JsonCodec:
    """The JsonCodec class contains utility methods that encode and decode Alfa objects to and from JSON."""

    @staticmethod
    def from_json(json_str: str, builder_config = BuilderConfig()):
        """Constructs an Alfa object from a JSON string"""
        obj = json.loads(json_str)
        return JsonCodec._from_dict(None, obj, builder_config)


    @staticmethod
    def _from_dict_value(val, t: type, alfatype, builder_config = BuilderConfig()):
        valtype = type(val)

        if val == "" and t != str:
            return None

        if ( t == int or t == str or t == float or t == bool ) and valtype == t:
            return val

        elif ( t == float ) and valtype == str:
            return float(val)

        elif ( t == int ) and valtype == str:
            return int(val)

        elif t == datetime.date:
            if alfatype is not None and alfatype.strPattern is not None:
                pat = alfatype.strPattern
                pat = pat.replace("YYYY", "%Y")
                pat = pat.replace("YY", "%y")
                pat = pat.replace("MM", "%m")
                pat = pat.replace("DD", "%d")
                return datetime.datetime.strptime(val, pat).date()
            else:
                return datetime.date.fromisoformat(val)

        elif t == datetime.datetime:
            return datetime.datetime.fromisoformat(val)

        elif t == datetime.time:
            return datetime.time.fromisoformat(val)

        elif t == isodate.Duration:
            return isodate.parse_duration(val)

        elif t == uuid.UUID and valtype == str:
            return uuid.UUID(val)

        elif t == UnionUntypedCase and val is None:
            return UnionUntypedCase()

        elif t == bytes:
            return base64.b64decode(val)

        elif t == decimal.Decimal:
            # remove comma in 1000s separator
            if isinstance(val, str) and val.__contains__(","):
                val = val.replace(",", "")

            return decimal.Decimal(val)

        elif ClassLoader.is_uri_class(t):
            return urllib.parse.urlparse(val)

        elif ClassLoader.is_alfa_nativetype(t):
            return t(val)

        elif Validator._is_optional(t) and val is not None:
            args = t.__args__

            from alfa.rt.model.OptionalDataType import OptionalDataType

            if isinstance(alfatype, OptionalDataType):
                alfatype = alfatype.ComponentType
            return JsonCodec._from_dict_value(val, args[0], alfatype, builder_config)

        else:

            t_str = str(t)

            if t_str.startswith("alfa.rt.Try.Try["):
                args = t.__args__
                if "Result" in val:
                    return alfa.rt.Try.Try.create_Result( JsonCodec._from_dict_value(val["Result"], args[0], None, builder_config) )
                elif "Failure" in val:
                    return alfa.rt.Try.Try.create_Failure( JsonCodec._from_dict_value(val["Failure"], alfa.rt.TryFailure.TryFailure, None, builder_config ) )
                else:
                    raise Exception("Result or Failure not found")

            elif t_str.startswith("alfa.rt.Either.Either["):
                args = t.__args__
                if "Left" in val:
                    return alfa.rt.Either.Either.create_Left( JsonCodec._from_dict_value(val["Left"], args[0], None, builder_config) )
                elif "Right" in val:
                    return alfa.rt.Either.Either.create_Right( JsonCodec._from_dict_value(val["Right"], args[1], None, builder_config) )
                else:
                    raise Exception("Left or Right not found")

            elif t_str.startswith("alfa.rt.Compressed.Compressed["):
                args = t.__args__
                decoded_bytes = base64.b64decode(val)
                return alfa.rt.Compressed.Compressed.from_bytes_value(decoded_bytes, args[0])

            elif t_str.startswith("alfa.rt.Encrypted.Encrypted["):
                args = t.__args__
                decoded_bytes = base64.b64decode(val)
                return alfa.rt.Encrypted.Encrypted.from_bytes_value(decoded_bytes, args[0])

            elif t_str.startswith("typing.Mapping["):
                m = {}
                args = t.__args__

                if valtype == dict:
                    for e in val:
                        k = JsonCodec._from_dict_value(e, args[0], None, builder_config)
                        v = JsonCodec._from_dict_value(val[e], args[1], None, builder_config)
                        m[k] = v

                elif valtype == list:
                    for i in range(len(val)):
                        map_entry = val[i]

                        entry_key = map_entry['key']
                        entry_val = map_entry['val']
                        k = JsonCodec._from_dict_value(entry_key, args[0], None, builder_config)
                        v = JsonCodec._from_dict_value(entry_val, args[1], None, builder_config)
                        m[k] = v

                else:
                    raise Exception("Unhandled case " + str(t) + " " + val )

                return m

            elif t_str.startswith("typing.Sequence[") and valtype == list:
                args = t.__args__
                lst = []

                from alfa.rt.model.ListDataType import ListDataType

                if isinstance(alfatype,ListDataType):
                    alfatype = alfatype.ComponentType

                for i in range(len(val)):
                    lst.append(JsonCodec._from_dict_value(val[i], args[0], alfatype, builder_config))
                return lst

            elif t_str.startswith("typing.Set["):
                args = t.__args__
                lst = set()

                from alfa.rt.model.SetDataType import SetDataType

                if isinstance(alfatype,SetDataType):
                    alfatype = alfatype.ComponentType

                for i, e in zip( range(len(val)), val ):
                    lst.add(JsonCodec._from_dict_value(e, args[0], alfatype, builder_config))
                return frozenset(lst)

            elif t_str.startswith("typing.Union[") and val is None:
                return None

            elif ClassLoader.is_alfa_udt_class(t):
                if t._alfa_descriptor().alfa_type() == UdtMetaType.enumType:
                    enumClz = ClassLoader.load(t._alfa_descriptor().name())
                    return enumClz[val]
                else:
                    return JsonCodec._from_dict(t, val)


        raise Exception("Unhandled case " + str(t) + " for value " + str(val) )

    @staticmethod
    def _from_dict(expected_type: type, dict_obj:dict, builder_config = BuilderConfig() ):
        if "$type" in dict_obj:
            type_name = dict_obj["$type"]
        else:
            type_name = expected_type.__module__

        clazz = ClassLoader.load(type_name)
        model = clazz._alfa_descriptor()

        if model.alfa_type() == UdtMetaType.unionType:
            for k in dict_obj.keys():
                if k == "$type":
                    continue

                opt_t = model.all_fields()[k].type
                t = opt_t.__args__[0]
                v = JsonCodec._from_dict_value(dict_obj[k], t, None, builder_config)
                uo = clazz.create(k, v)
                return uo

            raise Exception("Union decode error")

        elif model.alfa_type() == UdtMetaType.enumType:
            pass

        else:
            builder = clazz.new_builder( builder_config )

            for f in model.all_fields():
                ft = model.all_fields().get(f).type
                alfatype = model.field_alfa_type(f)

                try:
                    if f in dict_obj:
                        v = JsonCodec._from_dict_value(dict_obj[f], ft, alfatype, builder_config)
                        if v is not None:
                            setattr(builder, f, v)

                    elif f == '__key__':
                        v = JsonCodec._from_dict_value(dict_obj['$key'], ft, alfatype, builder_config)
                        setattr(builder, f, v)

                    elif Validator._is_optional(ft):
                        setattr(builder, f, None)

                    else:
                        raise Exception("Mandatory field '" + f + "' not supplied")

                except Exception as ex:
                    err = "Error reading field " + f + ". " + str(ex)
                    raise Exception(err)


            for e in dict_obj:
                if e == "$type":
                    continue
                elif e == "$key":
                    continue
                if e not in model.all_fields():
                    raise Exception("Unknown field '" + e + "' in JSON. Expected one of " + str( list(model.all_fields().keys())) )

            return builder.build()


    @staticmethod
    def to_json(alfa_obj):
        """Constructs a JSON representation of an Alfa object"""
        obj = JsonCodec._to_dict(alfa_obj)
        return JsonCodec._dict_to_json(obj)

    @staticmethod
    def _dict_to_json(dict_obj):
        return json.dumps(dict_obj, indent=4)

    @staticmethod
    def _to_dict(alfa_obj):
        dic = { }

        if not hasattr(alfa_obj, '_alfa_descriptor'):
            raise Exception( type(alfa_obj).__qualname__ + " is not an Alfa object. If its a Builder, build() should be called to create an AlfaObject.")

        descriptor = alfa_obj._alfa_descriptor()

        dic["$type"] = descriptor.name()

        if descriptor.alfa_type() == UdtMetaType.unionType:
            opt_ft = descriptor.all_fields()[alfa_obj.case_name()].type
            ft = opt_ft.__args__[0]
            dic[alfa_obj.case_name()] = JsonCodec._to_dict_value(alfa_obj.case_value(), ft)

        elif descriptor.alfa_type() == UdtMetaType.enumType:
            return alfa_obj.name

        else:
            for f in descriptor.all_fields().values():
                v = getattr(alfa_obj, f.name)

                if v is None:
                    continue

                fname = f.name
                if fname == '__key__':
                    fname = "$key"

                dic[fname] = JsonCodec._to_dict_value(v, f.type)

        return dic

    @staticmethod
    def _is_scalar_type(t):
        return t == str or t == int

    @staticmethod
    def _to_dict_value(val: object, t: type):

        if t == int or t == str or t == float or t == bool:
            return val

        elif t == datetime.date:
            return val.isoformat()

        elif t == datetime.datetime:
            return val.isoformat()

        elif t == isodate.Duration:
            return str(val)

        elif t == datetime.timedelta:
            return val.isoformat()

        elif t == datetime.time:
            return val.isoformat()

        elif t == uuid.UUID:
            return str(val)

        elif t == bytes:
            return base64.b64encode(val).decode('ascii')

        elif ClassLoader.is_uri_class(t):
            return str(val.geturl())

        elif t == UnionUntypedCase and val.__class__ == UnionUntypedCase:
            return None

        elif t == decimal.Decimal:
            return str(val)

        elif ClassLoader.is_alfa_nativetype(t):
            return val.encode_to_string()

        elif Validator._is_optional(t) and val is not None:
            args = t.__args__
            return JsonCodec._to_dict_value(val, args[0])

        else:
            t_str = str(t)
            valtype = type(val)

            if t_str.startswith("alfa.rt.Try.Try["):
                args = t.__args__
                dic = {}

                if val.is_Result():
                    v = JsonCodec._to_dict_value(val.Result, args[0])
                else:
                    v = JsonCodec._to_dict_value(val.Failure, alfa.rt.TryFailure.TryFailure)

                dic[val.case_name()] = v
                return dic

            elif t_str.startswith("alfa.rt.Either.Either["):
                args = t.__args__
                dic = {}
                if val.is_Left():
                    v = JsonCodec._to_dict_value(val.Left, args[0])
                else:
                    v = JsonCodec._to_dict_value(val.Right, args[1])

                dic[val.case_name()] = v
                return dic

            elif t_str.startswith("alfa.rt.Compressed.Compressed["):
                b64_str = base64.b64encode(val.encoded).decode('ascii')
                return b64_str

            elif t_str.startswith("alfa.rt.Encrypted.Encrypted["):
                b64_str = base64.b64encode(val.encoded).decode('ascii')
                return b64_str
                # args = t.__args__
                # as_obj = JsonCodec._to_dict_value(val.enclosed, args[0])
                # json_str = json.dumps(as_obj)
                # comp = gzip.compress( bytes( json_str, 'utf-8') )
                # b64_str = base64.b64encode(comp).decode('ascii')
                # return b64_str

            elif t_str.startswith("typing.Mapping[") and valtype == dict:
                args = t.__args__

                is_scalar_key = JsonCodec._is_scalar_type(args[0])
                if is_scalar_key:
                    m = {}
                else:
                    m = []

                for e in val:
                    k = JsonCodec._to_dict_value(e, args[0])
                    v = JsonCodec._to_dict_value(val[e], args[1])

                    if is_scalar_key:
                        m[k] = v
                    else:
                        m.append( {'key': k, 'val': v} )

                return m

            elif t_str.startswith("typing.Sequence[") and valtype == list:
                args = t.__args__
                lst = []
                for i in range(len(val)):
                    lst.append(JsonCodec._to_dict_value(val[i], args[0]))
                return lst

            elif t_str.startswith("typing.Union[") and val is None:
                return None

            elif t_str.startswith("typing.Set[") and (valtype == set or valtype == frozenset):
                lst = []
                args = t.__args__
                for i, e in zip( range(len(val)), val ):
                    lst.append(JsonCodec._to_dict_value(e, args[0]))
                return lst

            elif ClassLoader.is_alfa_udt_class(t):
                return JsonCodec._to_dict(val)


        raise Exception("Type not handled:" + str(t) + ". Value: " + str(val))
