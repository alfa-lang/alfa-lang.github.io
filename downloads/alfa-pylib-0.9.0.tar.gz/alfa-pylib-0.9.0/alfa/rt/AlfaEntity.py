from abc import abstractmethod

from alfa.rt.AlfaObject import AlfaObject
from alfa.rt.AlfaKey import AlfaKey
import typing

class AlfaEntity(AlfaObject):
    """Base class implemented by all Alfa Python objects corresponding to entities in Alfa."""

    @abstractmethod
    def key(self) -> typing.Optional[AlfaKey]:
        ...
