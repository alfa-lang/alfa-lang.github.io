import abc

class AlfaService(abc.ABC):
    """Base class implemented by all Alfa Python service objects"""
    pass
