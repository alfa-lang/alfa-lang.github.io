
class AlfaFieldMeta:
    pass

