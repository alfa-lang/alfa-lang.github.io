class Stack:
    def __init__(self):
        self.stack = []

    def push(self, e):
        self.stack.append(e)

    def pop(self):
        self._notempty()
        return self.stack.pop()

    def _notempty(self):
        if len(self.stack) <= 0:
            raise Exception("Empty stack")

    def peek(self):
        self._notempty()
        return self.stack[-1]

    def delimited_str(self, d):
        return d.join(self.stack)

    def is_empty(self):
        return len(self.stack) == 0
