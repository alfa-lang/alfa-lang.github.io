import typing
import alfa.rt.model.DecisionTable__HitPolicy
import alfa.rt.DecisionExecTableRow

class DecisionExecTable:
    def __init__(self, inputs : typing.List[typing.Any],
                 hp : alfa.rt.model.DecisionTable__HitPolicy.DecisionTable__HitPolicy,
                 rules : typing.List[alfa.rt.DecisionExecTableRow.DecisionExecTableRow]):
        self.inputs = inputs
        self.rules = rules
        self.policy = hp

    def execute(self) -> typing.List[typing.Any]:
        results = []
        for rule in self.rules:
            result = rule.evaluate(self.inputs)
            if result != None:
                results.append(result)

        return results

        # switch (policy) {
        #     case first:
        #     case unique:
        #     case anyof:
        # }

        # res = rules.
        #         stream().
        #         parallel().
        #         map(dr -> dr.evaluate(inputs)).
        #         filter(e -> e.isPresent()).
        #         map(e -> (T) e.get()).
        #         collect(Collectors.toList())

        # return res