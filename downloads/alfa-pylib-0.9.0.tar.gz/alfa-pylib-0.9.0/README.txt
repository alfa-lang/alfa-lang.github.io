Core utilities for Alfa Python Support

Packaging based on https://packaging.python.org/tutorials/packaging-projects/
