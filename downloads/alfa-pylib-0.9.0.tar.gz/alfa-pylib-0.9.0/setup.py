
import setuptools

setuptools.setup(
    name="alfa-pylib",
    version="0.9.0",
    author="Schematiks",
    author_email="support@alfa-lang.io",
    description="Alfa Core Python Package",
    url="www.alfa-lang.io",
    license='Proprietary',
    packages=setuptools.find_packages(),
    zip_safe=False
)
      
